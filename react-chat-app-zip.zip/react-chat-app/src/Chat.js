// import React, { useState, useEffect,useRef } from 'react';
// import io from 'socket.io-client';

// const socket = io('http://localhost:5000'); // Replace with your server URL

// const Chat = () => {
//   const [message, setMessage] = useState('');
//   const [messages, setMessages] = useState([]);
//   const socketRef = useRef();

//   useEffect(() => {
//     socketRef.current = io('http://localhost:5000');
//     socketRef.current.on('connect', () => {
//       console.log('connected to socket');
//     });
//     socketRef.current.on('message', (message) => {
//       setMessages((messages) => [...messages, message]);
//     });
//     socketRef.current.on('disconnect', () => {
//       console.log('disconnected from socket');
//     });
//     // Clean up the socket when the component unmounts
//     return () => {
//       socketRef.current.disconnect();
//     };
//   }, []);

// //   useEffect(() => {
// //     // Listen for incoming messages
// //     console.log('connect',socket.connected)
// //     socket.on('message', (message) => {
// //       setMessages((messages) => [...messages, message]);
// //     });
// //   }, []);

//   const sendMessage = (e) => {
//     e.preventDefault();
//     const newMessage = {
//         id: 1,
//         message: message,
//         sender: 'me',
//         image: 'https://example.com/image.jpg',
//         time: new Date().toISOString(),
//       };

//     // Emit a message to the server
//     socket.emit('message',newMessage);

//     // Clear the message input field
//     setMessage('');
//   };

//   return (
//     <div>
//       <h1>Chat App</h1>
//       <div>
//         {messages.map((message, index) => (
//           <div key={index}>{message}</div>
//         ))}
//       </div>
//       <form onSubmit={sendMessage}>
//         <input
//           type="text"
//           value={message}
//           onChange={(e) => setMessage(e.target.value)}
//         />
//         <button type="submit">Send</button>
//       </form>
//     </div>
//   );
// };

// export default Chat;

// import React, { useState, useEffect, useRef } from 'react';
// import socketIOClient from 'socket.io-client';

// const ENDPOINT = 'http://localhost:5000';

// const Chat = () => {
//   const [message, setMessage] = useState('');
//   const [messages, setMessages] = useState([]);
//   const socketRef = useRef();
// console.log('messages',messages)
//   useEffect(() => {
//     socketRef.current = socketIOClient(ENDPOINT);

//     socketRef.current.on('connect', () => {
//       console.log('connected to socket');
//     });

//     socketRef.current.on('message', (message) => {
//       setMessages((messages) => [...messages, message]);
//     });

//     socketRef.current.on('disconnect', () => {
//       console.log('disconnected from socket');
//     });

//     // Clean up the socket when the component unmounts
//     return () => {
//       socketRef.current.disconnect();
//     };
//   }, []);

//   const sendMessage = (e) => {
//     e.preventDefault();
//     const newMessage = {
//       id: 1,
//       message: message,
//       sender: 'me',
//       image: 'https://example.com/image.jpg',
//       time: new Date().toISOString(),
//     };

//     // Emit a message to the server
//     socketRef.current.emit('message', newMessage);

//     // Clear the message input field
//     setMessage('');
//   };

//   return (
//     <div>
//       <h1>Chat App</h1>
//       <div style={{display:'flex'}}>
//         {messages.map((message, index) => (
//             <div>
//           <div key={index}>{message.message}</div>
//           <div key={index}>{message.id}</div>
//           <div key={index}>{message.sender}</div>
//           {message.image && <img src={message.image} alt="Image" />}
//           <div key={index}>{message.time}</div>
//           </div>
//         ))}
//       </div>
//       <form onSubmit={sendMessage}>
//         <input
//           type="text"
//           value={message}
//           onChange={(e) => setMessage(e.target.value)}
//         />
//         <button type="submit">Send</button>
//       </form>
//     </div>
//   );
// };

// export default Chat;

// import React, { useState, useEffect, useRef } from 'react';
// import io from 'socket.io-client';

// const socket = io('http://localhost:5000'); // Replace with your server URL

// const Chat = () => {
//   const [message, setMessage] = useState('');
//   const [messages, setMessages] = useState([]);
//   const socketRef = useRef();

//   useEffect(() => {
//     socketRef.current = io('http://localhost:5000', );
//     socketRef.current.on('connect', () => {
//       console.log('connected to socket');
//     });
//     socketRef.current.on('message', (message) => {
//       setMessages((messages) => [...messages, message]);
//     });
//     socketRef.current.on('disconnect', () => {
//       console.log('disconnected from socket');
//     });
//     // Clean up the socket when the component unmounts
//     return () => {
//       socketRef.current.disconnect();
//     };
//   }, []);

//   const sendMessage = (e) => {
//     e.preventDefault();
//     const newMessage = {
//       id: 1,
//       message: message,
//       sender: 'other',
//       image: 'https://www.google.com/url?sa=i&url=https%3A%2F%2Funsplash.com%2Fs%2Fphotos%2Fbaby-dog&psig=AOvVaw0puJZSwOQaVyQq3lVH9Q96&ust=1683706354727000&source=images&cd=vfe&ved=0CBEQjRxqFwoTCPC8_Yrl5_4CFQAAAAAdAAAAABAD',
//       time: new Date().toISOString(),
//     };

//     // Emit a message to the server
//     socket.emit('message', newMessage);

//     // Clear the message input field
//     setMessage('');
//   };

//   return (
//     <div>
//       <h1>Chat App</h1>
//       <div>
//         {messages.map((message, index) => (
//           <div key={index}>
//             {message.sender === 'me' ? (
//               <p>
//                 <strong>You:</strong> {message.message}
//               </p>
//             ) : (
//               <p>
//                 <strong>{message.sender}:</strong> {message.message}
//               </p>
//             )}
//             {message.image && <img src={message.image} alt="dog" />}
            
//             <p>{message.time}</p>
//           </div>
//         ))}
//       </div>
//       <form onSubmit={sendMessage}>
//         <input
//           type="text"
//           value={message}
//           onChange={(e) => setMessage(e.target.value)}
//         />
//         <button type="submit">Send</button>
//       </form>
//     </div>
//   );
// };

// export default Chat;

import React, { useState, useRef, useEffect } from 'react';
import {
  Button,
  List,
  ListItem,
  TextField,
  ListItemAvatar,
  Avatar,
  InputAdornment ,IconButton ,
  Typography,
  Box
} from '@mui/material';
import AttachFileIcon from '@mui/icons-material/AttachFile';
import io from 'socket.io-client';



const Chat = () => {
  const [message, setMessage] = useState('');
  const [messages, setMessages] = useState([]);
  const fileInputRef = useRef(null);
  const messagesEndRef = useRef(null);
  const socketRef = useRef();

 
const UserId = 31

const receiverId = 33

  console.log('socket',socketRef)

  useEffect(() => {
    console.log('hi')
   
    socketRef.current = io('http://localhost:5000');
    socketRef.current.on("getMessage", (data) => {
      console.log(data)
        //  setMessages((messages) => [...messages, data?.text]);
      // setArrivalMessage({
      //   sender: senderId,
      //   text: text,
      //   createdAt: Date.now(),
      // });
    });
    socketRef.current.on('connect', () => {
      console.log('connected to socket');
    });
    
    socketRef.current.emit('addUser', UserId);

        socketRef.current.on('getUsers', (users) => {
          console.log('users',users)
    });
 
        socketRef.current.on('message', (message) => {
      setMessages((messages) => [...messages, message]);
    });
 
    socketRef.current.on('disconnect', () => {
      console.log('disconnected from socket');
    });
    // Clean up the socket when the component unmounts
    return () => {
      socketRef.current.disconnect();
    };
  }, []);

  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages]);

  const sendMessage = () => {

    if (message.trim()) {
        const newMessage = {
            id: messages.length + 1, message, sender: 'other' ,  time: new Date().toLocaleTimeString()
        }
    //   setMessages([        ...messages,        { id: messages.length + 1, message, sender: 'other' ,  time: new Date().toLocaleTimeString(),  },      ]);
    socketRef.current.emit('message', newMessage);
    socketRef.current.emit("sendMessage", {
      senderId: UserId,
      receiverId,
      text: newMessage,
    });
      setMessage('');
    }
  };

  const handleKeyDown = (event) => {
    if (event.key === 'Enter') {
      event.preventDefault();
      sendMessage();
    }
  };

  const handleFileInputChange = (event)  => {
    if (event.target.files && event.target.files.length > 0) {
      const file = event.target.files[0];
      const reader = new FileReader();
      reader.onload = (e) => {
        const imageSrc = e.target?.result ;
        const newMessage = {
            id: messages.length + 1, message, sender: 'me', image: imageSrc,   time: new Date().toLocaleTimeString()
        }
        // setMessages([          ...messages,          { id: messages.length + 1, message: '', sender: 'me', image: imageSrc,   time: new Date().toLocaleTimeString(), },        ]);
        socketRef.current.emit('message', newMessage);
        setMessage('');
    };
      reader.readAsDataURL(file);
    }
  };

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', height: '80vh' }}>
      <Box sx={{  display: 'flex',
  backgroundColor: '#DCF8C6',
  // borderRadius: '20px',
  padding: '10px 20px',
  justifyContent: 'center',
  alignItems: 'center',
  textAlign: 'center'}}>
      <ListItemAvatar>
                  <Avatar />
                </ListItemAvatar>
        <Typography sx={{justifyContent:'center' ,textAlgin:'center' ,justifyItems: 'center'}}>UserName Hi</Typography>
      </Box>
      <Box sx={{ padding: '5px'}}>

      </Box>
      <Box sx={{ flexGrow: 1, overflow: 'auto' }}>
        <List>
          {messages.map((message) => (
            <ListItem
              key={message.id}
              sx={{
                justifyContent: message.sender === 'me' ? 'flex-end' : 'flex-start',
              }}
            >
            
                <ListItemAvatar>
                  <Avatar />
                </ListItemAvatar>
      
          <Box          sx={{
            display: 'flex', flexDirection: 'column',
                  borderRadius: '20px',
                  backgroundColor: message.sender === 'me' ? '#DCF8C6' : '#a9d3da',
                  padding: '5px',
                  maxWidth: '40%',
                  wordWrap: 'break-word',
                }}>
         <Box>
          <Typography>
            {message.message}
          </Typography>
         </Box>
         <Box  sx ={{ display: 'flex', flexDirection: 'column'}}>
         <Box>
          {message.image ? (
                <img src={message.image} alt="attached" style={{ maxWidth: '200px' }} />
              ) : (
             null
              )}
       </Box>
        <Box sx ={{ display: 'flex', justifyContent: 'space-between',marginTop:2 }} >
        <Typography >
           {message.sender === 'me' ? 'You' : 'Other'}
       </Typography>
       <Box sx={{padding:1}}></Box>
       <Typography color='#44595c'  >
        {message.time}
       </Typography>

       </Box>
    
       </Box>
          </Box>
        

            </ListItem>
          ))}
            <div ref={messagesEndRef} />
        </List>
      </Box>
      <Box sx ={{ display: 'flex', alignItems: 'center', padding: 1  ,  justifyContent: 'center',
  textAlign: 'center' , marginLeft:10}}>
        <TextField
          label="Type a message"
          variant="outlined"
          fullWidth
          value={message}
          onChange={(event) => { setMessage(event.target.value); }}
          onKeyDown={handleKeyDown}
          style={{ marginRight: 16 }}
                  InputProps={{
              endAdornment: (
                <InputAdornment position="end">
                   <IconButton
                onClick={() => fileInputRef.current?.click()}
                  
                  >
                 <AttachFileIcon/>
                  </IconButton> 
                </InputAdornment>
              ),
            }}
        />
        <Button variant="contained" color="primary" onClick={sendMessage} sx ={{ marginRight: 16 }}>
          Send
        </Button>
   
        <input type="file" ref={fileInputRef} style={{ display: 'none' }} onChange={handleFileInputChange} accept="image/*" />
      </Box>
    </Box>
  )
};

export default Chat;


